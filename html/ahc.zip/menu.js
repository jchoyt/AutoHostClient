document.write('<table width=100%><tr><td align=center>' );
document.write('<a href=ahc.html>Home</a> | ');
document.write('<a href=ahclient.jar>Download</a> | ');
document.write('<a href=mailto:jchoyt@users.sourceforge.net>Source</a> | ');
document.write('<a href=ahc_license.html>License</a> | ');
document.write('<a href=faq.html>FAQ</a> | ');
document.write('<a href=mailto:jchoyt@users.sourceforge.net>Contact me</a> | ');
document.write('<a href="https://sourceforge.net/tracker/?atid=546423&group_id=76218&func=browse">Feature Request</a> | ');
document.write('<a href="https://sourceforge.net/tracker/?atid=546420&group_id=76218&func=browse">Bug Reports</a>');
document.write('</td></tr></table>');

